OPTINEL — Déploiement rapide (Netlify Drop / GitHub Pages)

1) Netlify (le plus simple)
   - Allez sur https://app.netlify.com/drop
   - Faites glisser (drag & drop) le fichier optinel-site.zip ci-dessous.
   - Netlify déploie directement et vous donne une URL.
   - Si vous avez un domaine, vous pourrez l'attacher ensuite.

2) GitHub Pages
   - Créez un dépôt (par ex. optinel-site).
   - Glissez-y le contenu dézippé (index.html et le dossier assets/).
   - Dans Settings > Pages, choisissez "Deploy from a branch" (main / root).
   - L'URL sera du type https://<votre-user>.github.io/optinel-site/

Notes:
- Ce site utilise Tailwind CDN et lucide (icônes) chargés en ligne, il faut donc une connexion internet.
- Remplacez assets/optinel-logo.png par votre vrai logo quand vous l'aurez.
- Pour modifier le contact, éditez la section <section id="contact"> dans index.html.
